# Smart Diab — Diabetes Progression Prediction with Machine Learning

Smart Diab is an educational machine-learning project that compares regression models on the diabetes dataset bundled with scikit-learn. It estimates a **disease-progression score** from tabular measurements and groups estimated scores into Low, Medium, and High bands based on training-set percentiles.

> **Important:** This is a learning/demo project, not a medical device. The score bands are not clinically validated diabetes-risk categories and must not be used for diagnosis, treatment, or medical decisions.

## What the project does
- Uses scikit-learn's built-in diabetes dataset: **442 samples, 10 input features**.
- Compares Linear Regression, Ridge, Lasso, Random Forest, Gradient Boosting, and a small MLP neural network.
- Uses 5-fold cross-validation on the training split and evaluates on a held-out test split.
- Reports R², MAE, and RMSE; generates plots and JSON/CSV summaries.

## Project files
```text
smart-diab/
├── diabetes_progression.py
├── requirements.txt
├── README.md
├── PRESENTATION_GUIDE.md
└── results/
    ├── 01_correlation.png
    ├── 02_model_comparison.png
    ├── 03_predictions_and_residuals.png
    ├── 04_feature_importance.png
    ├── 05_risk_band_confusion.png
    ├── metrics.json
    └── model_comparison.csv
```

## Run it (optional)
Python 3.10+ recommended. Install the dependencies with `pip install -r requirements.txt`, then run `python diabetes_progression.py`. If you do not want to use Command Prompt, you can still present the already-generated charts and metrics in the `results/` folder.

## Results from the included run
The code was executed successfully. The fixed random split produced 353 training rows and 89 test rows.

| Model | CV R² mean | Test R² | Test MAE | Test RMSE |
|---|---:|---:|---:|---:|
| Linear Regression | 0.449 | 0.453 | 42.794 | 53.853 |
| Ridge | 0.380 | 0.419 | 46.139 | 55.474 |
| Lasso | 0.456 | 0.472 | 42.854 | 52.898 |
| Random Forest | 0.411 | 0.474 | 42.968 | 52.801 |
| Gradient Boosting | 0.406 | 0.482 | 42.546 | 52.373 |
| Neural Network (MLP) | 0.324 | 0.452 | 42.901 | 53.890 |

- **Selected model by mean cross-validation R²:** Lasso (CV R² = 0.456).
- **Highest test R² in this run:** Gradient Boosting (Test R² = 0.482). The model-selection rule uses cross-validation, not the test set.
- **Score-band accuracy:** 60.67%.
- **Within one band:** 97.75%.

These are results from one fixed split and are not a claim of clinical accuracy.

## Outputs
| File | What it shows |
|---|---|
| `01_correlation.png` | Feature/target correlation heatmap |
| `02_model_comparison.png` | Cross-validation and test R² |
| `03_predictions_and_residuals.png` | Predicted vs actual scores and errors |
| `04_feature_importance.png` | Permutation feature importance |
| `05_risk_band_confusion.png` | Actual vs predicted score bands |
| `metrics.json` | Structured metrics and summary |
| `model_comparison.csv` | Model metrics in spreadsheet-friendly format |

## Dataset and methodology
The dataset is provided by scikit-learn; no separate download is required. See the [scikit-learn diabetes dataset documentation](https://scikit-learn.org/stable/datasets/toy_dataset.html#diabetes-dataset). The script splits the data with a fixed random seed, compares six regression models with 5-fold cross-validation on the training data, selects by mean CV R², then evaluates on the held-out test data.

## How to present
1. Explain the goal: estimate a progression score from numerical health measurements.
2. Show the dataset size and the ten input features.
3. Explain why multiple models were compared.
4. Show the model-comparison chart and discuss R², MAE, and RMSE.
5. Show feature importance and prediction/residual plots.
6. Clearly state limitations: small educational dataset, target is a progression score, and bands are not medical diagnoses.

## Future improvements
- Add a Streamlit interface for a live browser demo.
- Add tests, a model card, and reproducible environment versions.
- Only consider medical use after appropriate data validation, domain-expert review, and regulatory assessment.
